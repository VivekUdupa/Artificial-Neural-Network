Pledge:
On my honor I have neither given nor received aid on this project.
ALL CODES WERE WRITTEN IN MALTAB R2017a

vkoodli-report_takehome1.pdf	-   takehome #1 report

codes				- contains the following matlab codes
	run.m			      	-   function to run the entire code. includes displaying the output
	my_net.m				-   code with the initialization of parameters. 
	train.m				-   MLFF training code
	Feedforeward.m			-   MLFF code
	neuron.m				-   code to calculate the activation of individual unit 	
	sigmoid.m			-   logistic squasher code
	backpropogation.m		-   code for backpropogation
	set_alpha.m			-   code to set unwanted alpha elements to zero
	set_zero.m			-   code to set unwanted weight elementst to zero
	dim_bias_count			-   to calculate the unit count in each layer including  the bias
	weight_count 			-   code to calculate the total number of weights required.
	weight_corr.m			-   function to update the weights

Plots				- plots and results

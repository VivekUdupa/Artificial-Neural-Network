function w = weight_corr(dys,opt)
    
    w = opt .* dys;

end
function E = Energy(o,W)
%this function calculates the energy of hte given state

    E = -0.5 * o' * W * o;

end %functinm
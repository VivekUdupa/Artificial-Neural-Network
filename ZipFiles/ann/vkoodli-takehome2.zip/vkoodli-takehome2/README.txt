Pledge:
On my honor I have neither given nor received aid on this project.
ALL CODES WERE WRITTEN IN MALTAB R2017a


vkoodli-report_takehome2.pdf	-   takehome #2 report
Codes				-  This file contains all the matlab codes used
DATA 				-  Contaisn the data set used for the takehome  
Gif				-  Contains Gif of states converging
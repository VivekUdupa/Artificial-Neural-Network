I have read the ECE 8720 Spring 2018 course syllabus.
